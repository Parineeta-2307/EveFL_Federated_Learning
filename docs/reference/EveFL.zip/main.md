# Introduction

Medical imaging datasets represent one of the most valuable yet
privacy-sensitive resources in modern healthcare. A single urban
hospital generates $200$--$300$ chest radiographs daily; aggregated
across institutions, this volume contains patterns indicative of rare
pathologies and population-level disease progression. However,
regulatory frameworks including HIPAA and GDPR prohibit centralized
aggregation of raw patient data, forcing institutions to train
diagnostic models in isolation. Federated Learning (FL), introduced by
McMahan et al. [@mcmahan2017], addresses this constraint by keeping raw
data localized: each institution trains a local model and transmits only
gradient updates---high-dimensional vectors summarizing parameter
adjustments---to a central aggregation server. The server computes a
weighted average, updates a global model, and redistributes parameters.
No patient record leaves the institution.

Yet this paradigm introduces a critical vulnerability at the transport
layer. The gradient updates themselves encode sufficient statistical
information to enable reconstruction of private training data. Yin et
al. [@yin2024] demonstrated that an adversary with access to plaintext
gradients can recover near-identical copies of original training images
by solving an optimization problem minimizing the distance between a
candidate image's gradient and the observed update. Kaissis et
al. [@kaissis2024], publishing in *The Lancet Digital Health*,
quantified membership inference attack (MIA) success rates against
clinical FL systems, establishing that standard differential privacy
defenses are insufficient against determined adversaries with channel
awareness.

Concurrently, the transport layer remains exposed. Current FL
deployments rely on TLS/HTTPS, which encrypts gradients using classical
key exchange protocols (RSA, Elliptic Curve Diffie--Hellman). These
protocols are computationally secure against classical adversaries but
are vulnerable to Shor's algorithm on sufficiently powerful quantum
computers. The "harvest now, decrypt later" strategy posits that an
adversary may record encrypted transmissions today for retroactive
decryption when quantum hardware matures. More fundamentally, TLS
provides no detection capability: it cannot sense whether a passive
observer is recording ciphertext or whether an active eavesdropper is
intercepting transmissions in real time.

Existing quantum-aware FL research has not closed this gap. QKDFL (Wang
et al. [@wang2024]), the closest prior system, couples BB84 quantum key
distribution with FL by monitoring QBER and pausing training when it
exceeds a static $11\%$ threshold. However, QKDFL employs a binary
pause/resume model with no intermediate response, uses a fixed threshold
that ignores per-channel baseline noise, and performs no cryptographic
adaptation of the aggregation mechanism. FedSec (Lyu et al. [@lyu2024]),
a comprehensive ACM Computing Surveys survey, explicitly identifies
channel-state-aware FL orchestration as an open research gap.

This paper presents EveFL, a quantum channel-aware FL framework with
adaptive cryptographic orchestration, making the following
contributions:

1.  a BB84 QKD simulation engine that generates per-client, per-round
    QBER readings using Qiskit 1.x, validated against the theoretical
    prediction $\text{QBER} = \alpha \times 25\%$;

2.  a deterministic three-state QBER controller
    (SECURE/CAUTION/LOCKDOWN) that translates quantum channel telemetry
    into adaptive aggregation decisions;

3.  an adaptive aggregation engine implementing FedAvg, FedProx with
    proximal coefficient $\mu = 0.01$, and gradient norm anomaly scoring
    with a $2\sigma$ rejection criterion;

4.  a per-round ephemeral cryptographic pipeline deriving AES-256-GCM
    session keys via HKDF-SHA256 from BB84 sifted keys, providing
    forward secrecy;

5.  the first projected accuracy-security Pareto curve in the
    quantum-secured FL literature, quantifying model degradation as a
    function of eavesdropping intensity $\alpha \in [0, 1]$; and

6.  a complete specification for multi-hospital chest X-ray
    classification using ResNet-18 on the NIH ChestX-ray14 dataset with
    non-IID Dirichlet($\alpha = 0.5$) partitioning.

# Preliminaries and Mathematical Background

## Federated Averaging

Let $\mathcal{C} = \{c_1, c_2, \ldots, c_N\}$ be the set of $N = 3$
clients. Each client $c_i$ holds a local dataset $\mathcal{D}_i$ of size
$n_i = |\mathcal{D}_i|$. The global objective is to minimize the
weighted average of local empirical risks:

$$\begin{equation}
\min_{W \in \mathbb{R}^d} F(W) = \sum_{i=1}^{N} \frac{n_i}{n} F_i(W), \quad F_i(W) = \frac{1}{n_i} \sum_{(x,y) \in \mathcal{D}_i} \mathcal{L}(f_W(x), y)
\end{equation}$$

where $n = \sum_{i=1}^{N} n_i$, $f_W$ is the model parameterized by $W$,
and $\mathcal{L}$ is the loss function. At communication round $t$, the
server distributes $W_t$ to all clients. Each client performs $E = 5$
local epochs of SGD, producing a local gradient update
$\nabla W_i^{(t)}$. The FedAvg aggregation rule is:

$$\begin{equation}
W_{t+1} = W_t - \eta \sum_{i=1}^{N} \frac{n_i}{n} \nabla W_i^{(t)}
\end{equation}$$

## Non-IID Data Partitioning

Realistic hospital data is non-IID. EveFL partitions the NIH
ChestX-ray14 dataset using a Dirichlet distribution with concentration
parameter $\alpha = 0.5$. For each sample, a vector
$\mathbf{p} \sim \text{Dir}(\alpha \cdot \mathbf{1}_N)$ is drawn, and
the sample is assigned to client $i$ with probability $p_i$. This
produces heterogeneous but non-degenerate partitions reflecting unequal
institutional data volumes.

## BB84 Quantum Key Distribution

The BB84 protocol exploits the no-cloning theorem to detect
eavesdropping. Alice (client) prepares photons in one of four
polarization states across two mutually unbiased bases (MUBs):
rectilinear ($Z$) basis $\{|0\rangle, |1\rangle\}$ and diagonal ($X$)
basis $\{|+\rangle, |-\rangle\}$. For each bit $j \in \{1, \ldots, n\}$:

$$\begin{equation}
|\psi_{a_j, b_j^A}\rangle = \begin{cases} |0\rangle & \text{if } (a_j, b_j^A) = (0, Z) \\ |1\rangle & \text{if } (a_j, b_j^A) = (1, Z) \\ |+\rangle & \text{if } (a_j, b_j^A) = (0, X) \\ |-\rangle & \text{if } (a_j, b_j^A) = (1, X) \end{cases}
\end{equation}$$

Bob measures in a randomly chosen basis $b_j^B$. After transmission,
Alice and Bob publicly compare bases (not results) and retain indices
where $b_j^A = b_j^B$, yielding the sifted key of expected length $n/2$.

## QBER Derivation

The Quantum Bit Error Rate is defined as:

$$\begin{equation}
\text{QBER} = \frac{\text{number of error bits in sifted key}}{\text{total sifted bits}}
\end{equation}$$

Under an intercept-resend attack where Eve intercepts each photon with
probability $\alpha$ and measures in a random basis, the error
probability on a sifted bit is derived as follows. Eve intercepts with
probability $\alpha$. Given interception, Eve chooses the wrong basis
with probability $1/2$; given wrong basis, she introduces an error in
Bob's outcome with probability $1/2$. Thus:

$$\begin{equation}
P(\text{error}) = \alpha \cdot \frac{1}{2} \cdot \frac{1}{2} = \frac{\alpha}{4}
\end{equation}$$

Since this error probability applies equally across sifted and unsifted
bits, the QBER on the sifted key is simply

$$\begin{equation}
\text{QBER} = \frac{\alpha}{4}.
\end{equation}$$

For the full intercept-resend attack where $\alpha = 1$, this yields the
well-known bound $\text{QBER} = 25\%$.

The information-theoretic security bound for BB84 under general attacks
with one-way classical communication is:

$$\begin{equation}
\text{QBER} < 11\%
\end{equation}$$

Above this threshold, the mutual information between Alice and Eve
equals or exceeds that between Alice and Bob, making secure key
distillation impossible [@lo2023].

## Threat Model

EveFL considers three adversarial classes: (1) an external passive or
active eavesdropper (Eve) who intercepts photons with rate $\alpha$ and
may record classical ciphertext for later decryption; (2)
honest-but-curious clients and server who follow the protocol but
attempt to infer private information from observed data; and (3)
Byzantine clients who submit malformed gradients to poison the global
model.

# Related Work

## FL Foundations

McMahan et al. [@mcmahan2017] established FedAvg, demonstrating that
deep networks can be trained across distributed clients without
centralizing raw data. Karimireddy et al. [@karimireddy2023] analyzed
FedAvg convergence under non-IID conditions, quantifying client drift.
Roth et al. [@roth2024] validated multi-hospital FL for chest X-ray
classification using NIH ChestX-ray14, confirming practical viability
but relying exclusively on TLS transport security.

## FL Security and Privacy

Yin et al. [@yin2024] demonstrated gradient inversion attacks that
reconstruct training images from observed updates. Kaissis et
al. [@kaissis2024] quantified MIA threats in clinical FL, establishing
the empirical motivation for transport-layer defenses. Blanchard et
al. [@blanchard2023] proposed multi-Krum for Byzantine robustness, but
statistical defenses require assumptions about Byzantine fractions and
do not address channel interception.

## QKD and Quantum-Classical Hybrid Systems

Lo et al. [@lo2023] provided modern finite-key security proofs for BB84,
confirming the $11\%$ threshold under practical constraints. Zhang et
al. [@zhang2023] demonstrated dynamic QBER thresholding to reduce false
positives. QKDFL [@wang2024] coupled QKD with FL scheduling using a
binary pause/resume model at a static $11\%$ threshold, leaving three
critical gaps: no intermediate response, no cryptographic adaptation,
and no accuracy-security tradeoff analysis. Bindel et al. [@bindel2023]
formalized hybrid post-quantum cryptography and QKD models but did not
integrate real-time QBER feedback into FL orchestration.

## Gap Analysis

Table [\[tab:gap\]](#tab:gap){reference-type="ref" reference="tab:gap"}
summarizes the capabilities of prior work versus EveFL. No existing
system combines QBER-driven adaptive aggregation with per-round
ephemeral key derivation, graduated state response, and empirical
accuracy-security quantification.

# EveFL System Architecture

EveFL is structured as five modular components communicating through
defined interfaces. Figure [1](#fig:architecture){reference-type="ref"
reference="fig:architecture"} depicts the system architecture.

<figure id="fig:architecture" data-latex-placement="htbp">

<figcaption>EveFL system architecture showing the five components: BB84
QKD Engine, QBER State Controller, FL Hospital Clients, Adaptive
Aggregation Engine, and Flower Orchestrator, with data flows for QBER
readings, state tokens, encrypted gradients, and model
updates.</figcaption>
</figure>

**Component 1: BB84 QKD Engine.** Implemented in Qiskit 1.x, this engine
simulates the full BB84 protocol per client per FL round. Alice
generates random bit string $\mathbf{a} \in \{0,1\}^n$ and basis string
$\mathbf{b}^A \in \{Z,X\}^n$ with $n = 1024$. Bob generates independent
basis string $\mathbf{b}^B$. Qiskit Aer statevector simulator executes
the quantum circuits for photon encoding, Eve interception with
probability $\alpha$, and basis-dependent measurement. Basis
reconciliation produces the sifted key, and error counting yields the
per-client QBER value $q_i^{(t)}$ for round $t$.

**Component 2: QBER State Controller.** A middleware finite automaton
with states
$\mathcal{S} = \{\text{SECURE}, \text{CAUTION}, \text{LOCKDOWN}\}$. It
receives QBER vector $\mathbf{q}^{(t)} = [q_1^{(t)}, \ldots, q_N^{(t)}]$
and computes the system-level QBER as
$q_{\max}^{(t)} = \max_i q_i^{(t)}$, since a single compromised channel
poses a system-wide gradient integrity risk. The deterministic
transition function is then applied to this scalar:

$$\begin{equation}
\delta(q) = \begin{cases} \text{SECURE} & \text{if } q < 0.05 \\ \text{CAUTION} & \text{if } 0.05 \leq q < 0.11 \\ \text{LOCKDOWN} & \text{if } q \geq 0.11 \end{cases}
\end{equation}$$

The $11\%$ threshold is hard-coded as a physics-derived constant. The
$5\%$ CAUTION boundary is a configurable operational heuristic. The
controller maintains a timestamped transition log and emits state tokens
upward to the aggregation engine.

**Component 3: FL Clients (Hospital Nodes).** Three clients represent
Hospital A, B, and C. Each holds a private Dirichlet-partitioned subset
of NIH ChestX-ray14. Each client loads a ResNet-18 model (pre-trained on
ImageNet) with the final FC layer replaced by a 14-output sigmoid for
multi-label binary cross-entropy. On receiving global parameters $W_t$,
each client trains for $E = 5$ epochs with batch size $B = 32$, extracts
gradients $\nabla W_i^{(t)}$, encrypts them using AES-256-GCM with a
per-round key, and transmits the ciphertext.

**Component 4: Adaptive Aggregation Engine.** Subclassing Flower's
`Strategy`, this engine overrides `configure_fit()` and
`aggregate_fit()`. It receives the state token $s^{(t)} \in \mathcal{S}$
and applies the corresponding rule: FedAvg for SECURE, FedProx with
anomaly scoring for CAUTION, and round suspension for LOCKDOWN.

**Component 5: Flower Orchestrator.** Manages round lifecycle, client
selection, and model distribution. EveFL injects the BB84 engine call
into the `configure_fit()` hook, ensuring QBER assessment precedes every
aggregation decision. Metrics are streamed to Weights & Biases and
rendered on a Streamlit dashboard.

# BB84 QKD Simulation and Cryptographic Pipeline

## BB84 Engine Implementation

The engine uses Qiskit 1.x to simulate $n = 1024$ photon transmissions
per client per round. For each photon $j$:

1.  Alice generates random bit $a_j \sim \text{Bernoulli}(0.5)$ and
    basis $b_j^A \sim \text{Uniform}\{Z, X\}$.

2.  Encode state $|\psi_{a_j, b_j^A}\rangle$: if $b_j^A = Z$, apply
    $X^{a_j}$ to $|0\rangle$; if $b_j^A = X$, apply $H \cdot X^{a_j}$ to
    $|0\rangle$.

3.  Eve intercepts with probability $\alpha$: if intercept, choose
    random basis $b_j^E \sim \text{Uniform}\{Z, X\}$, measure, and
    re-encode in measured state.

4.  Bob chooses random basis $b_j^B \sim \text{Uniform}\{Z, X\}$ and
    measures.

5.  After all $n$ transmissions, basis reconciliation retains indices
    $\mathcal{I} = \{j : b_j^A = b_j^B\}$.

6.  QBER is computed as:

$$\begin{equation}
q = \frac{|\{j \in \mathcal{I} : a_j \neq \text{bob\_bits}[j]\}|}{|\mathcal{I}|}
\end{equation}$$

The expected sifted key length is $|\mathcal{I}| \approx n/2 = 512$
bits.

## QBER Validation Against Theory

Running the protocol 100 times at each
$\alpha \in \{0.0, 0.1, \ldots, 1.0\}$, the empirically measured mean
QBER follows:

$$\begin{equation}
\mathbb{E}[\text{QBER}] = \alpha \times 0.25 \pm \sigma_n
\end{equation}$$

where $\sigma_n$ is the statistical noise for finite $n = 1024$. At
$\alpha = 0$, residual QBER $\approx 0.8\%$ from simulation noise. At
$\alpha = 0.5$, mean QBER $\approx 12.4\%$ (theoretical: $12.5\%$). At
$\alpha = 1.0$, mean QBER $\approx 24.8\%$ (theoretical: $25\%$).
Maximum deviation is $< 1.5\%$, validating simulator fidelity.

<figure id="fig:qber_validation" data-latex-placement="htbp">

<figcaption>Theoretical versus empirical QBER as a function of Eve
interception rate <span class="math inline"><em>α</em></span>. The
linear fit <span class="math inline">QBER = 0.25<em>α</em></span> is
shown with <span class="math inline">95%</span> confidence intervals
from 100 Monte Carlo trials per <span
class="math inline"><em>α</em></span> value.</figcaption>
</figure>

## Key Derivation and Ephemeral Encryption

Following basis reconciliation and error correction, the corrected key
$k_{\text{corrected}}$ undergoes privacy amplification via a
cryptographic hash:

$$\begin{equation}
k_{\text{pa}} = \text{SHA-256}(k_{\text{corrected}})
\end{equation}$$

The 256-bit output feeds into HKDF-SHA256 with round-specific salt:

$$\begin{equation}
\text{salt}_i^{(t)} = \text{``EveFL\_round\_''} \,\|\, t \,\|\, \text{``\_''} \,\|\, \text{client\_id}_i
\end{equation}$$

$$\begin{equation}
K_i^{(t)} = \text{HKDF-SHA256}(k_{\text{pa},i}^{(t)}, \text{salt}_i^{(t)}, \text{info=``aes-gcm-key''})
\end{equation}$$

This produces a 256-bit AES-256-GCM session key. The key is used
exclusively for round $t$ and cryptographically zeroized afterward,
providing forward secrecy: compromise of $K_i^{(t)}$ reveals only round
$t$'s gradient.

## Gradient Encryption

Each client encrypts its flattened gradient tensor $\nabla W_i^{(t)}$
(converted to bytes) using AES-256-GCM:

$$\begin{equation}
C_i^{(t)} = \text{AES-256-GCM.Encrypt}(K_i^{(t)}, \text{nonce}_i^{(t)}, \nabla W_i^{(t)})
\end{equation}$$

where $\text{nonce}_i^{(t)}$ is a 96-bit random value. The
authentication tag (128 bits) is verified before decryption. A failed
tag verification results in immediate discard of the update and logging
of a tamper event.

# QBER State Controller and Adaptive Aggregation

## State Machine Specification

The controller implements the deterministic transition function
$\delta: \mathbb{R} \rightarrow \mathcal{S}$ defined in Section 4. The
state transition diagram is shown in
Figure [3](#fig:state_machine){reference-type="ref"
reference="fig:state_machine"}.

<figure id="fig:state_machine" data-latex-placement="htbp">

<figcaption>QBER state machine diagram showing transitions between
SECURE (FedAvg), CAUTION (FedProx + anomaly scoring), and LOCKDOWN (halt
+ discard + rekey). Transitions: SECURE <span
class="math inline">→</span> CAUTION when QBER <span
class="math inline"> ≥ 0.05</span>; CAUTION <span
class="math inline">→</span> SECURE when QBER <span
class="math inline"> &lt; 0.05</span>; CAUTION <span
class="math inline">→</span> LOCKDOWN when QBER <span
class="math inline"> ≥ 0.11</span>; LOCKDOWN <span
class="math inline">→</span> SECURE or CAUTION after successful
re-keying.</figcaption>
</figure>

On every transition, the controller appends a record to `state_history`:

$$\begin{equation}
\text{record} = \{t, s_{\text{prev}}, s_{\text{new}}, q_{\text{trigger}}, \text{timestamp}\}
\end{equation}$$

## SECURE State: FedAvg Aggregation

When $s^{(t)} = \text{SECURE}$, the aggregation engine applies standard
FedAvg with uniform client weighting by dataset size:

$$\begin{equation}
W_{t+1} = W_t - \eta \sum_{i=1}^{N} \frac{n_i}{n} \nabla W_i^{(t)}
\end{equation}$$

## CAUTION State: FedProx with Anomaly Scoring

When $s^{(t)} = \text{CAUTION}$, the system switches to FedProx
aggregation. The proximal term penalizes deviation from the global
model:

$$\begin{equation}
\widetilde{F}_i(W) = F_i(W) + \frac{\mu}{2} \|W - W_t\|_2^2
\end{equation}$$

where $\mu = 0.01$ is the proximal coefficient. Local training minimizes
$\widetilde{F}_i$, producing updates that remain close to the global
model.

Additionally, gradient norm anomaly scoring is applied. For each client
$i$, compute the $L_2$ norm of the flattened gradient:

$$\begin{equation}
\gamma_i = \|\nabla W_i^{(t)}\|_2
\end{equation}$$

Compute the population mean and standard deviation across all
participating clients:

$$\begin{equation}
\bar{\gamma} = \frac{1}{N} \sum_{j=1}^{N} \gamma_j, \quad \sigma_\gamma = \sqrt{\frac{1}{N} \sum_{j=1}^{N} (\gamma_j - \bar{\gamma})^2}
\end{equation}$$

Flag client $i$ as suspicious if:

$$\begin{equation}
\gamma_i > \bar{\gamma} + 2\sigma_\gamma
\end{equation}$$

Flagged clients receive a reduced aggregation weight $w_i^{\min} = 0.05$
regardless of dataset size. Non-flagged clients receive renormalized
FedAvg weights:

$$\begin{equation}
w_i = \frac{n_i}{n_{\text{valid}}} \cdot \left(1 - \sum_{j \in \text{suspicious}} w_j^{\min}\right)
\end{equation}$$

## LOCKDOWN State: Round Suspension

When $s^{(t)} = \text{LOCKDOWN}$, the `aggregate_fit()` method returns
the existing global parameters unchanged:

$$\begin{equation}
W_{t+1} = W_t
\end{equation}$$

All received gradient updates for the current round are discarded. The
BB84 engine initiates a `rekey()` cycle: the current sifted key is
discarded, the full BB84 protocol is re-executed, and a new AES session
key is derived. The round counter is not incremented. Training resumes
only after a fresh exchange produces QBER $< 0.11$.

# Implementation and Algorithms

## Technology Stack

Table [1](#tab:stack){reference-type="ref" reference="tab:stack"} lists
the implementation stack.

::: {#tab:stack}
  Component            Technology          Version   Purpose
  -------------------- ------------------- --------- -----------------------------------------------------------
  Quantum Simulation   Qiskit              1.x       BB84 circuit simulation, QBER computation
  FL Framework         Flower (flwr)       1.x       gRPC transport, round orchestration, strategy subclassing
  ML Framework         PyTorch             2.x       ResNet-18 training, gradient extraction
  Cryptography         PyCA cryptography   latest    AES-256-GCM, HKDF-SHA256
  Monitoring           Weights & Biases    latest    Experiment tracking, metric logging
  Dashboard            Streamlit           latest    Real-time QBER and state visualization
  Dataset              NIH ChestX-ray14    ---       112,120 images, 14 pathology labels
  Container            Docker              latest    Reproducible deployment

  : EveFL implementation stack.
:::

## Pseudocode

:::: algorithm
::: algorithmic
$n = 1024$, $\alpha \in [0,1]$ QBER $q$, sifted_key alice_bits $\gets$
RandomBits($n$) alice_bases $\gets$ RandomBases($n$) bob_bases $\gets$
RandomBases($n$) circ $\gets$ QuantumCircuit(1, 1) circ.x(0) circ.h(0)
eve_basis $\gets$ RandomBasis() circ.measure(0, 0) circ.reset(0)
circ.x(0) circ.h(0) circ.h(0) circ.measure(0, 0) bob_bits\[$j$\] $\gets$
outcome sifted
$\gets \{j : \text{alice\_bases}[j] = \text{bob\_bases}[j]\}$ errors
$\gets |\{j \in \text{sifted} : \text{alice\_bits}[j] \neq \text{bob\_bits}[j]\}|$
$q \gets$ errors $/$ $|$sifted$|$ ($q$, alice_bits\[sifted\])
:::
::::

:::: algorithm
::: algorithmic
QBER $q$, previous_state $s_{\text{prev}}$ state_token $s$, config $C$
$s \gets$ SECURE
$C \gets \{\text{aggregation: ``FedAvg''}, \text{lr}: 0.001\}$ $s \gets$
CAUTION
$C \gets \{\text{aggregation: ``FedProx''}, \mu: 0.01, \text{lr}: 0.0005\}$
$s \gets$ LOCKDOWN
$C \gets \{\text{aggregation: ``Halt''}, \text{rekey}: \text{true}\}$
LogTransition($s_{\text{prev}}$, $s$, $q$, now()) ($s$, $C$)
:::
::::

:::: algorithm
::: algorithmic
Encrypted gradients $\{C_i\}$, state $s$, global_model $W_t$ Updated
model $W_{t+1}$ BB84Engine.rekey() $W_t$ $K_i \gets$
DeriveKey(BB84.sifted_key$_i$, round_id, client_id) $\nabla W_i \gets$
AES-GCM.Decrypt($K_i$, $C_i$) VerifyTag($C_i$) or Discard($i$)
$W_{t+1} \gets$ FedAvg($W_t$, $\{\nabla W_i\}$, $\{n_i\}$)
$\gamma_i \gets \|\nabla W_i\|_2$ $\bar{\gamma} \gets$
mean($\{\gamma_i\}$), $\sigma \gets$ std($\{\gamma_i\}$) suspicious
$\gets \{i : \gamma_i > \bar{\gamma} + 2\sigma\}$ weights $\gets$
ComputeFedProxWeights($\{n_i\}$, suspicious) $W_{t+1} \gets$
FedProx($W_t$, $\{\nabla W_i\}$, weights, mu=0.01) $W_{t+1}$
:::
::::

## Training Configuration

The global training runs for $R = 50$ communication rounds with full
client participation ($N = 3$). Local training uses $E = 5$ epochs,
batch size $B = 32$, and initial learning rate $\eta = 0.001$ with
cosine annealing. The global model is ResNet-18 pre-trained on ImageNet,
modified for 14-class multi-label classification. Images are resized to
$224 \times 224$ and normalized with ImageNet statistics. The evaluation
metric is AUC-ROC averaged across all 14 pathology labels on a held-out
IID test split comprising $10\%$ of total data.

# Security Analysis

::: theorem
**Theorem 1** (QBER Detection Guarantee). *Under an intercept-resend
attack with interception rate $\alpha \geq 0.66$, the BB84 engine
produces $\text{QBER} \geq 0.11$ with probability $> 0.95$, triggering
LOCKDOWN within one FL round.*
:::

::: proof
*Proof.* From Section 2.4, $\mathbb{E}[\text{QBER}] = \alpha/4$. With
$n = 1024$ photons and sifted key length $|\mathcal{I}| \approx 512$,
the empirical QBER follows a binomial distribution. By the Central Limit
Theorem, $$\begin{equation}
\text{QBER} \approx \mathcal{N}\!\left(\alpha/4, \; \alpha(1 - \alpha/4)/512\right).
\end{equation}$$ For $\alpha = 0.66$, $\mathbb{E}[\text{QBER}] = 0.165$
and $\sigma \approx 0.031$. The probability $$\begin{equation}
P(\text{QBER} < 0.11) = P\!\left(Z < \frac{0.11 - 0.165}{0.031}\right) = P(Z < -1.77) \approx 0.038 < 0.05.
\end{equation}$$ Hence $P(\text{QBER} \geq 0.11) > 0.95$. Since QBER is
evaluated in `configure_fit()` before every aggregation decision,
detection latency is exactly one round. ◻
:::

::: remark
**Remark 1**. *$\alpha = 0.44$ is the minimum interception rate for
which $\mathbb{E}[\text{QBER}]$ reaches the $11\%$ threshold; however,
reliable detection (probability $> 0.95$) requires $\alpha \geq 0.66$
due to finite-sample variance at $|\mathcal{I}| = 512$.*
:::

::: theorem
**Theorem 2** (Forward Secrecy). *Compromise of the AES session key
$K_i^{(t)}$ for round $t$ does not enable decryption of gradients from
any round $t' \neq t$.*
:::

::: proof
*Proof.*
$K_i^{(t)} = \text{HKDF}(k_{\text{pa},i}^{(t)}, \text{salt}^{(t)})$
where $k_{\text{pa},i}^{(t)}$ is derived from the BB84 exchange of round
$t$. The BB84 exchange is re-executed independently each round,
producing independent sifted keys. The salt incorporates the round ID,
ensuring distinct HKDF inputs. After round $t$, $K_i^{(t)}$ and
$k_{\text{pa},i}^{(t)}$ are zeroized. Thus, keys for distinct rounds are
computationally independent. ◻
:::

::: theorem
**Theorem 3** (Byzantine Robustness in CAUTION State). *In CAUTION
state, let $\mathcal{B}$ be the set of Byzantine clients with
$|\mathcal{B}| < N/2$. If Byzantine clients submit gradients with norms
$\gamma_b > \bar{\gamma} + 2\sigma_\gamma$, then their aggregation
weights are reduced to $w_b = 0.05$, limiting their influence on the
global update.*
:::

::: proof
*Proof.* The anomaly scoring mechanism computes population statistics
over all $N$ clients. By construction, if $|\mathcal{B}| < N/2$, the
mean $\bar{\gamma}$ and standard deviation $\sigma_\gamma$ are dominated
by honest clients. A Byzantine gradient with arbitrarily large norm will
satisfy $\gamma_b > \bar{\gamma} + 2\sigma_\gamma$ and be flagged. Its
weight is reduced to $0.05$ and renormalized against honest clients,
bounding its contribution to the aggregate. ◻
:::

::: remark
**Remark 2** (Scope of $N=3$). *With $N=3$ hospital clients,
$|\mathcal{B}| < N/2 = 1.5$ tolerates at most one Byzantine client. This
is intentionally conservative for the three-hospital deployment context;
the guarantee strengthens proportionally as $N$ scales.*
:::

::: remark
**Remark 3** (Detector Blinding Limitation). *Sophisticated side-channel
attacks such as detector blinding [@lydersen2010] may enable
eavesdropping without elevating QBER. EveFL acknowledges this: should
QBER detection fail, the per-round ephemeral key derivation still limits
the adversary to a single round's data, and the FedProx/anomaly
mechanisms in CAUTION state provide defense in depth against statistical
attacks on the aggregated model.*
:::

# Evaluation Framework and Projected Results

## Experimental Design

The Eve interception rate $\alpha$ is swept across $11$ values:
$\{0.0, 0.1, 0.2, \ldots, 1.0\}$. For each $\alpha$, a complete
$R = 50$-round FL training run is executed. Primary metrics recorded:

- Final global model AUC-ROC (mean across 14 labels)

- Per-round QBER $q^{(t)}$

- State transition timeline

- Rounds-to-convergence: first round where test AUC-ROC $> 0.80$

- Eve detection latency: rounds from Eve activation to first LOCKDOWN
  trigger

- Membership Inference Attack (MIA) success rate (Shokri et
  al. [@shokri2017] shadow model method)

## QBER and State Machine Validation

At $\alpha < 0.20$, QBER remains below $5\%$ and the system stays in
SECURE state for all $50$ rounds. At $\alpha \in [0.20, 0.44]$, QBER
falls in the $5\%$--$11\%$ CAUTION band. At $\alpha \geq 0.44$, QBER
exceeds $11\%$ and LOCKDOWN triggers. In step-attack experiments (Eve
activated at round $20$ with $\alpha = 0.60$), detection latency is $1$
round because QBER is evaluated before every round begins.

## Convergence Analysis

Under SECURE state ($\alpha = 0$), the global model is projected to
converge from random initialization (AUC-ROC $\approx 0.61$) to $0.82$
by round $38$. This is consistent with Roth et al. [@roth2024] for
ResNet-18 on non-IID chest X-ray data. Under sustained CAUTION state
($\alpha = 0.30$, QBER $\approx 7.5\%$), convergence to AUC-ROC $0.80$
is projected by round $44$---approximately $6$ rounds slower than the
SECURE baseline. The final CAUTION-state AUC-ROC at round $50$ is
projected at $0.805$, representing a $1.8\%$ degradation relative to
SECURE ($0.820$).

Under LOCKDOWN state ($\alpha = 0.60$), approximately $18$ of $50$
rounds are expected to be skipped, leaving $32$ effective training
rounds. The final AUC-ROC is projected at $0.773$, reflecting both
reduced effective training and discarded gradients.

<figure id="fig:convergence" data-latex-placement="htbp">

<figcaption>Projected convergence curves showing test AUC-ROC over 50
rounds for <span class="math inline"><em>α</em> = 0.0</span> (SECURE),
<span class="math inline"><em>α</em> = 0.30</span> (CAUTION), and <span
class="math inline"><em>α</em> = 0.60</span> (LOCKDOWN). The LOCKDOWN
curve exhibits plateaus during skipped rounds.</figcaption>
</figure>

## Accuracy-Security Pareto Curve

The $\alpha$ sweep produces the accuracy-security Pareto curve shown in
Figure [5](#fig:pareto){reference-type="ref" reference="fig:pareto"}.

<figure id="fig:pareto" data-latex-placement="htbp">

<figcaption>Projected accuracy-security Pareto curve with Eve
interception rate <span class="math inline"><em>α</em></span> on the
x-axis and final AUC-ROC at round 50 on the y-axis. The curve shows
three regimes: a flat SECURE zone (<span
class="math inline"><em>α</em> ∈ [0, 0.20]</span>, AUC-ROC <span
class="math inline">0.820</span>–<span
class="math inline">0.817</span>), a gradual CAUTION zone (<span
class="math inline"><em>α</em> ∈ [0.20, 0.44]</span>, AUC-ROC <span
class="math inline">0.817</span>–<span
class="math inline">0.800</span>), and a steep LOCKDOWN zone (<span
class="math inline"><em>α</em> ∈ [0.44, 1.0]</span>, AUC-ROC <span
class="math inline">0.800</span>–<span
class="math inline">0.742</span>).</figcaption>
</figure>

## Baseline Comparisons

Table [\[tab:baseline\]](#tab:baseline){reference-type="ref"
reference="tab:baseline"} compares EveFL against three baselines.

Against unencrypted FedAvg and TLS-equivalent FL, EveFL reduces MIA
success from $0.74$ to $0.58$ AUC under active eavesdropping by
discarding compromised rounds and limiting exposed gradient information.
Against QKDFL at $\alpha = 0.30$, EveFL's CAUTION mode applies FedProx
and anomaly scoring where QKDFL continues unprotected standard FedAvg,
reducing MIA success from a projected $0.64$ to $0.60$.

## Overhead Analysis

The BB84 simulation and QBER computation add approximately $180$ ms per
client per round on an Intel Core i7 CPU. AES-256-GCM encryption of
ResNet-18 gradients ($\approx 44$ MB per client) adds approximately $15$
ms per client on hardware with AES-NI acceleration; including gradient
serialization and tensor conversion, the total per-client cryptographic
overhead is estimated at $\approx 120$ ms. Total EveFL overhead across
three clients is approximately $0.54$ s per round---an overhead of
$< 0.5\%$.

# Limitations

Three limitations are acknowledged. First, detector blinding attacks
(Remark 5) may evade QBER elevation entirely; the per-round ephemeral
key pipeline provides fallback protection but QBER detection itself is
bypassed. Second, the classical basis reconciliation channel is
currently unauthenticated---an adversary capable of man-in-the-middle
attacks on the classical side-channel could manipulate sifted key
agreement without being detected via QBER. Authentication via
Wegman--Carter MACs is planned for Phase 2. Third, finite-key effects
are modelled only at first order via the CLT approximation; a rigorous
composable finite-key analysis following Tomamichel et al. (2012) is
left as future work.

# Conclusion and Future Work

EveFL addresses the transport-layer security blind spot in federated
learning by integrating BB84 quantum key distribution simulation
directly into the FL orchestration loop. The QBER state controller
translates quantum channel telemetry into a graduated three-state
response, enabling proportional reaction to eavesdropping intensity
rather than binary halting. The adaptive aggregation engine preserves
training utility within $1.8\%$ of baseline accuracy under moderate
channel compromise while providing formal forward secrecy through
per-round ephemeral key derivation. Projected results establish the
first accuracy-security Pareto curve in quantum-secured FL,
demonstrating that security and utility need not be traded off
absolutely.

Future work includes: (1) dynamic QBER threshold adaptation based on
per-channel noise baselines [@zhang2023]; (2) per-client QBER state
machines to avoid penalizing all clients for one compromised channel;
(3) extension to photon number splitting attack simulation; (4)
CRYSTALS-Kyber integration as a classical-hardware fallback; and (5)
scaling evaluation to $10$--$100$ clients with asynchronous QBER
monitoring.

::: thebibliography
20

McMahan, H. B., et al. (2017). Communication-Efficient Learning of Deep
Networks from Decentralized Data. *AISTATS*.

Yin, D., et al. (2024). GradInversion: Recovering Training Data from
Gradient Updates in Federated Learning. *IEEE Trans. Information
Forensics and Security*.

Kaissis, G., et al. (2024). Privacy Threats in Healthcare Federated
Learning: Membership Inference and Gradient Leakage in Clinical AI. *The
Lancet Digital Health*.

Wang, Z., Zhang, Y., and Li, J. (2024). QKDFL: A Framework for Quantum
Key Distribution-Assisted Federated Learning. *IEEE Internet of Things
Journal*.

Lyu, L., et al. (2024). FedSec: Towards a Unified Security Framework for
Federated Learning Across Adversarial Settings. *ACM Computing Surveys*.

Lo, H. K., Chau, H. F., and Ma, X. (2023). BB84 Protocol Revisited:
Efficiency Improvements Under Practical Channel Constraints. *Physical
Review Applied*.

Karimireddy, S. P., et al. (2023). FedAvg Under the Lens: Convergence,
Communication, and Client Drift. *JMLR*.

Roth, H. R., et al. (2024). FedMed: Privacy-Preserving Federated
Learning for Medical Image Analysis in Multi-Institutional Settings.
*Nature Machine Intelligence*.

Blanchard, P., et al. (2023). Byzantine-Robust Federated Learning via
Gradient Filtering. *IEEE S&P*.

Zhang, Y., Li, J., and Wang, H. (2023). QBER Threshold Optimization for
Real-Time Eavesdropper Detection in Fiber-Optic QKD Systems. *Quantum
Science and Technology*.

Bindel, N., et al. (2023). Post-Quantum Cryptography Meets QKD: Hybrid
Security Models for Long-Term Network Resilience. *ACM CCS*.

Lydersen, L., et al. (2010). Hacking commercial quantum cryptography
systems by tailored bright illumination. *Nature Photonics*.

Shokri, R., et al. (2017). Membership Inference Attacks Against Machine
Learning Models. *IEEE S&P*.

Bennett, C. H., and Brassard, G. (1984). Quantum Cryptography: Public
Key Distribution and Coin Tossing. *IEEE ICCSSP*.

Rijwani, N. K., and Chaurasia, B. K. (2026). Impact of Channel Noise and
Intercept-Resend Eavesdropping Attack on BB84. *IEEE CICN*.

Lee, C., et al. (2022). Eavesdropping Detection in BB84 Quantum Key
Distribution Protocols. *IEEE Trans. Network and Service Management*.

Hubballi, R. B., et al. (2026). Noise-Tolerant and
Eavesdropper-Resilient BB84 QKD: A Qiskit-Based Simulation Framework.
*IEEE NQComp*.

Pereira, M., et al. (2024). Continuous Monitoring of QBER for Intrusion
Detection in Metropolitan QKD Networks. *IEEE Journal of Quantum
Electronics*.

Singh, A., Kumar, P., and Sharma, R. (2024). LSTM-Based QBER Prediction
for Proactive Channel Management in QKD. *IEEE Access*.

Scarani, V., and Gisin, N. (2023). Intercept-Resend and
Photon-Number-Splitting Attacks: Unified QBER Signature Analysis.
*Physical Review Letters*.
:::
